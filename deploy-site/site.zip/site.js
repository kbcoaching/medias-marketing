/* =========================================================
   LIENS À BRANCHER — c'est le seul endroit à modifier.
   Colle tes liens entre les guillemets.
   ========================================================= */
var KB_LIENS = {
  // Lien d'achat de l'application (page de paiement)
  application: "https://plan.kbcoaching.fit",
  // Liens d'achat par produit
  alimentation: "https://plan.kbcoaching.fit/?vente=1",
  entrainement: "https://plan.kbcoaching.fit/mon-entrainement",
  forfait: "https://plan.kbcoaching.fit/?vente=1&forfait=1",
  // Lien pour réserver l'appel découverte (Calendly ou autre)
  rendezvous: "https://calendly.com/kb_coaching-yv7/30min"
};

/* Si un lien est vide, le bouton ouvre un courriel à la place. */
var KB_COURRIEL = "kb_coaching@hotmail.com";

(function () {
  function mail(sujet) {
    return "mailto:" + KB_COURRIEL + "?subject=" + encodeURIComponent(sujet);
  }
  // Mesure : chaque lien vers l'app indique qu'il vient du site et de quelle page (lu par l'onglet « Mesure » de l'app).
  var page = (location.pathname.replace(/^\/|\/$|\.html$/g, "") || "accueil").replace(/\//g, "-").replace(/[^a-z0-9-]/gi, "");
  function source(u) {
    if (!u || u.indexOf("https://plan.kbcoaching.fit") !== 0) return u;
    // Article de blogue : source « blogue », campagne = l'article (demande de Shakira, 2026-11-21).
    var blogue = /^blogue-./.test(page) && page !== "blogue-index";
    return u + (u.indexOf("?") < 0 ? "?" : "&") + "utm_source=" + (blogue ? "blogue" : "site") + "&utm_medium=bouton&utm_campaign=" + (blogue ? page.slice(7) : page);
  }
  ["application", "alimentation", "entrainement", "forfait"].forEach(function (k) { KB_LIENS[k] = source(KB_LIENS[k]); });
  document.querySelectorAll("[data-lien='retrouver']").forEach(function (a) { a.href = source(a.href); });
  document.querySelectorAll("form[name='guide-20-minutes'] input[name='page']").forEach(function (i) { i.value = page; });
  var app = KB_LIENS.application || mail("Je veux mon plan KB Coaching");
  ["alimentation", "entrainement", "forfait"].forEach(function (k) {
    var lien = KB_LIENS[k] || app;
    document.querySelectorAll("[data-lien='" + k + "']").forEach(function (a) { a.href = lien; });
  });
  var rdv = KB_LIENS.rendezvous || mail("Appel découverte — Programme Valet");
  document.querySelectorAll("[data-lien='application']").forEach(function (a) { a.href = app; });
  document.querySelectorAll("[data-lien='rendezvous']").forEach(function (a) { a.href = rdv; if (KB_LIENS.rendezvous) { a.target = "_blank"; a.rel = "noopener"; } });

  var header = document.querySelector(".header");
  var btn = document.querySelector(".menu-btn");
  if (header && btn) {
    btn.addEventListener("click", function () {
      var open = header.classList.toggle("open");
      btn.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }
  // Aucun mot coupé dans les titres : si un mot est plus large que sa boîte,
  // le titre rapetisse juste assez pour que le mot entier tienne (jusqu'à 55 % de sa taille).
  var TITRES = ".h1,.h2,.h3,.offer-title,.price-xl,.num,.stat";
  function ajuster() {
    document.querySelectorAll(TITRES).forEach(function (el) {
      if (el.dataset.taille === undefined) el.dataset.taille = el.style.fontSize || "";
      el.style.fontSize = el.dataset.taille;
      if (el.clientWidth === 0 || el.scrollWidth <= el.clientWidth + 1) return;
      var base = parseFloat(getComputedStyle(el).fontSize), t = base;
      while (el.scrollWidth > el.clientWidth + 1 && t > base * 0.55) { t -= 1; el.style.fontSize = t + "px"; }
    });
  }
  ajuster();
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(ajuster);
  var minuterie; window.addEventListener("resize", function () { clearTimeout(minuterie); minuterie = setTimeout(ajuster, 150); });

  var y = document.getElementById("annee");
  if (y) y.textContent = new Date().getFullYear();
})();
